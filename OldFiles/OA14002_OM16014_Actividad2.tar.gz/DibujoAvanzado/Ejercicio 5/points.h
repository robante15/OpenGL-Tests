#include <GL/gl.h>
#include <GL/glut.h>

void dibujo() {

    glBegin(GL_LINES);

    glVertex2f(-5.31f, 0.08f);
    glVertex2f(-5.31f, 0.9f);

    glVertex2f(-5.31f, 0.9f);
    glVertex2f(0.0f, 0.9f);

    glVertex2f(0.0f, 0.9f);
    glVertex2f(0.0f, 0.08f);

    glVertex2f(0.0f, 0.08f);
    glVertex2f(-5.31f, 0.08f);

    glVertex2f(5.31f, 0.08f);
    glVertex2f(5.31f, 0.9f);

    glVertex2f(5.31f, 0.9f);
    glVertex2f(0.0f, 0.9f);

    glVertex2f(0.0f, 0.9f);
    glVertex2f(0.0f, 0.08f);

    glVertex2f(0.0f, 0.08f);
    glVertex2f(5.31f, 0.08f);

    glVertex2f(-1.13f, 0.07f);
    glVertex2f(-1.13f, 0.95f);

    glVertex2f(-1.13f, 0.95f);
    glVertex2f(-1.2f, 0.95f);

    glVertex2f(-1.2f, 0.95f);
    glVertex2f(-1.2f, 0.07f);

    glVertex2f(-1.2f, 0.07f);
    glVertex2f(-1.13f, 0.07f);


    glVertex2f(1.13f, 0.07f);
    glVertex2f(1.13f, 0.95f);

    glVertex2f(1.13f, 0.95f);
    glVertex2f(1.2f, 0.95f);

    glVertex2f(1.2f, 0.95f);
    glVertex2f(1.2f, 0.07f);

    glVertex2f(1.2f, 0.07f);
    glVertex2f(1.13f, 0.07f);

    glVertex2f(-1.2f, 0.72f);
    glVertex2f(-1.2f, 0.65f);

    glVertex2f(-1.2f, 0.65f);
    glVertex2f(0.0f, 0.65f);

    glVertex2f(0.0f, 0.65f);
    glVertex2f(0.0f, 0.72f);

    glVertex2f(0.0f, 0.72f);
    glVertex2f(-1.2f, 0.72f);

    glVertex2f(1.2f, 0.72f);
    glVertex2f(1.2f, 0.65f);

    glVertex2f(1.2f, 0.65f);
    glVertex2f(0.0f, 0.65f);

    glVertex2f(0.0f, 0.65f);
    glVertex2f(0.0f, 0.72f);

    glVertex2f(0.0f, 0.72f);
    glVertex2f(1.2f, 0.72f);

    glVertex2f(-1.2f, 0.47f);
    glVertex2f(-1.2f, 0.4f);

    glVertex2f(-1.2f, 0.4f);
    glVertex2f(0.0f, 0.4f);

    glVertex2f(0.0f, 0.4f);
    glVertex2f(0.0f, 0.47f);

    glVertex2f(0.0f, 0.47f);
    glVertex2f(-1.2f, 0.47f);

    glVertex2f(1.2f, 0.47f);
    glVertex2f(1.2f, 0.4f);

    glVertex2f(1.2f, 0.4f);
    glVertex2f(0.0f, 0.4f);

    glVertex2f(0.0f, 0.4f);
    glVertex2f(0.0f, 0.47f);

    glVertex2f(0.0f, 0.47f);
    glVertex2f(1.2f, 0.47f);

    glVertex2f(-1.2f, 0.2f);
    glVertex2f(-1.2f, 0.14f);

    glVertex2f(-1.2f, 0.14f);
    glVertex2f(0.0f, 0.14f);

    glVertex2f(0.0f, 0.14f);
    glVertex2f(0.0f, 0.2f);

    glVertex2f(0.0f, 0.2f);
    glVertex2f(-1.2f, 0.2f);

    glVertex2f(1.2f, 0.2f);
    glVertex2f(1.2f, 0.14f);

    glVertex2f(1.2f, 0.14f);
    glVertex2f(0.0f, 0.14f);

    glVertex2f(0.0f, 0.14f);
    glVertex2f(0.0f, 0.2f);

    glVertex2f(0.0f, 0.2f);
    glVertex2f(1.2f, 0.2f);

    glVertex2f(-5.37f, 0.07f);
    glVertex2f(-5.37f, 0.95f);

    glVertex2f(-5.37f, 0.95f);
    glVertex2f(-5.05f, 0.95f);

    glVertex2f(-5.05f, 0.95f);
    glVertex2f(-5.05f, 1.62f);

    glVertex2f(-5.05f, 1.62f);
    glVertex2f(-5.12f, 1.71f);

    glVertex2f(-5.12f, 1.71f);
    glVertex2f(-5.12f, 1.81f);

    glVertex2f(-5.12f, 1.81f);
    glVertex2f(-5.02f, 1.81f);

    glVertex2f(-5.02f, 1.81f);
    glVertex2f(-5.02f, 2.7f);

    glVertex2f(-5.02f, 2.7f);
    glVertex2f(-5.07f, 2.76f);

    glVertex2f(-5.07f, 2.76f);
    glVertex2f(-5.07f, 2.87f);

    glVertex2f(-5.07f, 2.87f);
    glVertex2f(-5.0f, 2.87f);

    glVertex2f(-5.0f, 2.87f);
    glVertex2f(-5.0f, 3.9f);

    glVertex2f(-5.0f, 3.9f);
    glVertex2f(-5.05f, 3.97f);

    glVertex2f(-5.05f, 3.97f);
    glVertex2f(-5.05f, 4.06f);

    glVertex2f(-5.05f, 4.06f);
    glVertex2f(-4.96f, 4.06f);

    glVertex2f(-4.96f, 4.06f);
    glVertex2f(-4.96f, 4.3f);

    glVertex2f(-4.96f, 4.3f);
    glVertex2f(-5.03f, 4.35f);

    glVertex2f(-5.03f, 4.35f);
    glVertex2f(-5.03f, 4.44f);

    glVertex2f(-5.03f, 4.44f);
    glVertex2f(-4.94f, 4.44f);

    glVertex2f(-4.94f, 4.44f);
    glVertex2f(-4.94f, 4.57f);

    glVertex2f(-4.94f, 4.57f);
    glVertex2f(-4.76f, 4.74f);

    glVertex2f(-4.76f, 4.74f);
    glVertex2f(-4.76f, 4.96f);

    glVertex2f(-4.76f, 4.96f);
    glVertex2f(-4.74f, 5.0f);


    glVertex2f(-4.74f, 5.0f);
    glVertex2f(-4.71f, 5.0f);

    glVertex2f(-4.71f, 5.0f);
    glVertex2f(-4.71f, 4.75f);

    glVertex2f(-4.71f, 4.75f);
    glVertex2f(-4.53f, 4.57f);

    glVertex2f(-4.53f, 4.57f);
    glVertex2f(-4.53f, 4.45f);

    glVertex2f(-4.53f, 4.45f);
    glVertex2f(-4.44f, 4.45f);

    glVertex2f(-4.44f, 4.45f);
    glVertex2f(-4.44f, 4.35f);

    glVertex2f(-4.44f, 4.35f);
    glVertex2f(-4.5f, 4.3f);

    glVertex2f(-4.5f, 4.3f);
    glVertex2f(-4.5f, 4.06f);

    glVertex2f(-4.5f, 4.06f);
    glVertex2f(-4.43f, 4.06f);

    glVertex2f(-4.43f, 4.06f);
    glVertex2f(-4.43f, 3.96f);

    glVertex2f(-4.43f, 3.96f);
    glVertex2f(-4.49f, 3.9f);

    glVertex2f(-4.49f, 3.9f);
    glVertex2f(-4.49f, 2.87f);

    glVertex2f(-4.49f, 2.87f);
    glVertex2f(-4.4f, 2.87f);

    glVertex2f(-4.4f, 2.87f);
    glVertex2f(-4.4f, 2.76f);

    glVertex2f(-4.4f, 2.76f);
    glVertex2f(-4.46f, 2.7f);

    glVertex2f(-4.46f, 2.7f);
    glVertex2f(-4.46f, 1.81f);

    glVertex2f(-4.46f, 1.81f);
    glVertex2f(-4.36f, 1.81f);

    glVertex2f(-4.36f, 1.81f);
    glVertex2f(-4.36f, 1.71f);

    glVertex2f(-4.36f, 1.71f);
    glVertex2f(-4.43f, 1.61f);

    glVertex2f(-4.43f, 1.61f);
    glVertex2f(-4.43f, 0.95f);

    glVertex2f(-4.43f, 0.95f);
    glVertex2f(-4.08f, 0.95f);

    glVertex2f(-4.08f, 0.95f);
    glVertex2f(-4.08f, 4.04f);

    glVertex2f(-4.08f, 4.04f);
    glVertex2f(-3.2f, 4.23f);

    glVertex2f(-3.2f, 4.23f);
    glVertex2f(-2.87f, 4.23f);

    glVertex2f(-2.87f, 4.23f);
    glVertex2f(-2.87f, 4.55f);

    glVertex2f(-2.87f, 4.55f);
    glVertex2f(-2.95f, 4.55f);

    glVertex2f(-2.95f, 4.55f);
    glVertex2f(-3.05f, 4.76f);

    glVertex2f(-3.05f, 4.76f);
    glVertex2f(-2.87f, 4.85f);


    glVertex2f(5.37f, 0.07f);
    glVertex2f(5.37f, 0.95f);

    glVertex2f(5.37f, 0.95f);
    glVertex2f(5.05f, 0.95f);

    glVertex2f(5.05f, 0.95f);
    glVertex2f(5.05f, 1.62f);

    glVertex2f(5.05f, 1.62f);
    glVertex2f(5.12f, 1.71f);

    glVertex2f(5.12f, 1.71f);
    glVertex2f(5.12f, 1.81f);

    glVertex2f(5.12f, 1.81f);
    glVertex2f(5.02f, 1.81f);

    glVertex2f(5.02f, 1.81f);
    glVertex2f(5.02f, 2.7f);

    glVertex2f(5.02f, 2.7f);
    glVertex2f(5.07f, 2.76f);

    glVertex2f(5.07f, 2.76f);
    glVertex2f(5.07f, 2.87f);

    glVertex2f(5.07f, 2.87f);
    glVertex2f(5.0f, 2.87f);

    glVertex2f(5.0f, 2.87f);
    glVertex2f(5.0f, 3.9f);

    glVertex2f(5.0f, 3.9f);
    glVertex2f(5.05f, 3.97f);

    glVertex2f(5.05f, 3.97f);
    glVertex2f(5.05f, 4.06f);

    glVertex2f(5.05f, 4.06f);
    glVertex2f(4.96f, 4.06f);

    glVertex2f(4.96f, 4.06f);
    glVertex2f(4.96f, 4.3f);

    glVertex2f(4.96f, 4.3f);
    glVertex2f(5.03f, 4.35f);

    glVertex2f(5.03f, 4.35f);
    glVertex2f(5.03f, 4.44f);

    glVertex2f(5.03f, 4.44f);
    glVertex2f(4.94f, 4.44f);

    glVertex2f(4.94f, 4.44f);
    glVertex2f(4.94f, 4.57f);

    glVertex2f(4.94f, 4.57f);
    glVertex2f(4.76f, 4.74f);

    glVertex2f(4.76f, 4.74f);
    glVertex2f(4.76f, 4.96f);

    glVertex2f(4.76f, 4.96f);
    glVertex2f(4.74f, 5.0f);


    glVertex2f(4.74f, 5.0f);
    glVertex2f(4.71f, 5.0f);

    glVertex2f(4.71f, 5.0f);
    glVertex2f(4.71f, 4.75f);

    glVertex2f(4.71f, 4.75f);
    glVertex2f(4.53f, 4.57f);

    glVertex2f(4.53f, 4.57f);
    glVertex2f(4.53f, 4.45f);

    glVertex2f(4.53f, 4.45f);
    glVertex2f(4.44f, 4.45f);

    glVertex2f(4.44f, 4.45f);
    glVertex2f(4.44f, 4.35f);

    glVertex2f(4.44f, 4.35f);
    glVertex2f(4.5f, 4.3f);

    glVertex2f(4.5f, 4.3f);
    glVertex2f(4.5f, 4.06f);

    glVertex2f(4.5f, 4.06f);
    glVertex2f(4.43f, 4.06f);

    glVertex2f(4.43f, 4.06f);
    glVertex2f(4.43f, 3.96f);

    glVertex2f(4.43f, 3.96f);
    glVertex2f(4.49f, 3.9f);

    glVertex2f(4.49f, 3.9f);
    glVertex2f(4.49f, 2.87f);

    glVertex2f(4.49f, 2.87f);
    glVertex2f(4.4f, 2.87f);

    glVertex2f(4.4f, 2.87f);
    glVertex2f(4.4f, 2.76f);

    glVertex2f(4.4f, 2.76f);
    glVertex2f(4.46f, 2.7f);

    glVertex2f(4.46f, 2.7f);
    glVertex2f(4.46f, 1.81f);

    glVertex2f(4.46f, 1.81f);
    glVertex2f(4.36f, 1.81f);

    glVertex2f(4.36f, 1.81f);
    glVertex2f(4.36f, 1.71f);

    glVertex2f(4.36f, 1.71f);
    glVertex2f(4.43f, 1.61f);

    glVertex2f(4.43f, 1.61f);
    glVertex2f(4.43f, 0.95f);

    glVertex2f(4.43f, 0.95f);
    glVertex2f(4.08f, 0.95f);

    glVertex2f(4.08f, 0.95f);
    glVertex2f(4.08f, 4.04f);

    glVertex2f(4.08f, 4.04f);
    glVertex2f(3.2f, 4.23f);

    glVertex2f(3.2f, 4.23f);
    glVertex2f(2.87f, 4.23f);

    glVertex2f(2.87f, 4.23f);
    glVertex2f(2.87f, 4.55f);

    glVertex2f(2.87f, 4.55f);
    glVertex2f(2.95f, 4.55f);

    glVertex2f(2.95f, 4.55f);
    glVertex2f(3.05f, 4.76f);

    glVertex2f(3.05f, 4.76f);
    glVertex2f(2.87f, 4.85f);

    glVertex2f(-2.79f, 4.85f);
    glVertex2f(-1.71f, 4.85f);
    glVertex2f(2.79f, 4.85f);
    glVertex2f(1.71f, 4.85f);

    glVertex2f(-1.71f, 4.85f);
    glVertex2f(-1.71f, 5.17f);
    glVertex2f(1.71f, 4.85f);
    glVertex2f(1.71f, 5.17f);

    glVertex2f(-2.96f, 4.72f);
    glVertex2f(-2.83f, 4.78f);

    glVertex2f(-2.83f, 4.78f);
    glVertex2f(-1.72f, 4.78f);

    glVertex2f(-1.72f, 4.78f);
    glVertex2f(-1.72f, 4.63f);

    glVertex2f(-1.72f, 4.63f);
    glVertex2f(-2.9f, 4.63f);

    glVertex2f(-2.9f, 4.63f);
    glVertex2f(-2.96f, 4.72f);


    glVertex2f(2.96f, 4.72f);
    glVertex2f(2.83f, 4.78f);

    glVertex2f(2.83f, 4.78f);
    glVertex2f(1.72f, 4.78f);

    glVertex2f(1.72f, 4.78f);
    glVertex2f(1.72f, 4.63f);

    glVertex2f(1.72f, 4.63f);
    glVertex2f(2.9f, 4.63f);

    glVertex2f(2.9f, 4.63f);
    glVertex2f(2.96f, 4.72f);


    glVertex2f(-2.8f, 4.22f);
    glVertex2f(-2.8f, 4.56f);

    glVertex2f(-2.8f, 4.56f);
    glVertex2f(-1.72f, 4.56f);

    glVertex2f(-1.72f, 4.56f);
    glVertex2f(-1.72f, 4.22f);

    glVertex2f(-1.72f, 4.22f);
    glVertex2f(-2.8f, 4.22f);


    glVertex2f(2.8f, 4.22f);
    glVertex2f(2.8f, 4.56f);

    glVertex2f(2.8f, 4.56f);
    glVertex2f(1.72f, 4.56f);

    glVertex2f(1.72f, 4.56f);
    glVertex2f(1.72f, 4.22f);

    glVertex2f(1.72f, 4.22f);
    glVertex2f(2.8f, 4.22f);


    glVertex2f(0.0f, 5.2f);
    glVertex2f(-1.65f, 5.19f);

    glVertex2f(-1.65f, 5.19f);
    glVertex2f(-1.65f, 4.22f);

    glVertex2f(-1.65f, 4.22f);
    glVertex2f(0.0f, 4.22f);

    glVertex2f(0.0f, 5.2f);
    glVertex2f(1.65f, 5.19f);

    glVertex2f(1.65f, 5.19f);
    glVertex2f(1.65f, 4.22f);

    glVertex2f(1.65f, 4.22f);
    glVertex2f(0.0f, 4.22f);

    glVertex2f(0.0f, 5.02f);
    glVertex2f(-1.42f, 5.02f);

    glVertex2f(-1.42f, 5.02f);
    glVertex2f(-1.42f, 4.37f);

    glVertex2f(-1.42f, 4.37f);
    glVertex2f(0.0f, 4.37f);


    glVertex2f(0.0f, 4.96f);
    glVertex2f(-1.36f, 4.95f);

    glVertex2f(-1.36f, 4.95f);
    glVertex2f(-1.36f, 4.43f);

    glVertex2f(-1.36f, 4.43f);
    glVertex2f(0.0f, 4.43f);


    glVertex2f(0.0f, 5.2f);
    glVertex2f(-1.65f, 5.19f);

    glVertex2f(-1.65f, 5.19f);
    glVertex2f(-1.65f, 4.22f);

    glVertex2f(-1.65f, 4.22f);
    glVertex2f(0.0f, 4.22f);

    glVertex2f(0.0f, 5.02f);
    glVertex2f(1.42f, 5.02f);

    glVertex2f(1.42f, 5.02f);
    glVertex2f(1.42f, 4.37f);

    glVertex2f(1.42f, 4.37f);
    glVertex2f(0.0f, 4.37f);


    glVertex2f(0.0f, 4.96f);
    glVertex2f(1.36f, 4.95f);

    glVertex2f(1.36f, 4.95f);
    glVertex2f(1.36f, 4.43f);

    glVertex2f(1.36f, 4.43f);
    glVertex2f(0.0f, 4.43f);


    glVertex2f(-4.88f, 4.45f);
    glVertex2f(-4.58f, 4.45f);

    glVertex2f(-4.58f, 4.45f);
    glVertex2f(-4.58f, 4.53f);

    glVertex2f(-4.58f, 4.53f);
    glVertex2f(-4.74f, 4.67f);

    glVertex2f(-4.74f, 4.67f);
    glVertex2f(-4.88f, 4.53f);

    glVertex2f(-4.88f, 4.53f);
    glVertex2f(-4.88f, 4.45f);


    glVertex2f(4.88f, 4.45f);
    glVertex2f(4.58f, 4.45f);

    glVertex2f(4.58f, 4.45f);
    glVertex2f(4.58f, 4.53f);

    glVertex2f(4.58f, 4.53f);
    glVertex2f(4.74f, 4.67f);

    glVertex2f(4.74f, 4.67f);
    glVertex2f(4.88f, 4.53f);

    glVertex2f(4.88f, 4.53f);
    glVertex2f(4.88f, 4.45f);

    glVertex2f(-4.98f, 4.39f);
    glVertex2f(-4.9f, 4.34f);

    glVertex2f(-4.9f, 4.34f);
    glVertex2f(-4.56f, 4.34f);

    glVertex2f(-4.56f, 4.34f);
    glVertex2f(-4.5f, 4.39f);

    glVertex2f(-4.5f, 4.39f);
    glVertex2f(-4.98f, 4.39f);


    glVertex2f(4.98f, 4.39f);
    glVertex2f(4.9f, 4.34f);

    glVertex2f(4.9f, 4.34f);
    glVertex2f(4.56f, 4.34f);

    glVertex2f(4.56f, 4.34f);
    glVertex2f(4.5f, 4.39f);

    glVertex2f(4.5f, 4.39f);
    glVertex2f(4.98f, 4.39f);

    glVertex2f(-4.9f, 4.26f);
    glVertex2f(-4.9f, 4.06f);

    glVertex2f(-4.9f, 4.06f);
    glVertex2f(-4.56f, 4.06f);

    glVertex2f(-4.56f, 4.06f);
    glVertex2f(-4.56f, 4.26f);

    glVertex2f(-4.56f, 4.26f);
    glVertex2f(-4.9f, 4.26f);


    glVertex2f(4.9f, 4.26f);
    glVertex2f(4.9f, 4.06f);

    glVertex2f(4.9f, 4.06f);
    glVertex2f(4.56f, 4.06f);

    glVertex2f(4.56f, 4.06f);
    glVertex2f(4.56f, 4.26f);

    glVertex2f(4.56f, 4.26f);
    glVertex2f(4.9f, 4.26f);


    glVertex2f(-4.99f, 3.99f);
    glVertex2f(-4.49f, 3.99f);

    glVertex2f(-4.49f, 3.99f);
    glVertex2f(-4.57f, 3.91f);

    glVertex2f(-4.57f, 3.91f);
    glVertex2f(-4.9f, 3.91f);

    glVertex2f(-4.9f, 3.91f);
    glVertex2f(-4.99f, 3.99f);


    glVertex2f(4.99f, 3.99f);
    glVertex2f(4.49f, 3.99f);

    glVertex2f(4.49f, 3.99f);
    glVertex2f(4.57f, 3.91f);

    glVertex2f(4.57f, 3.91f);
    glVertex2f(4.9f, 3.91f);

    glVertex2f(4.9f, 3.91f);
    glVertex2f(4.99f, 3.99f);


    glVertex2f(-4.91f, 3.85f);
    glVertex2f(-4.94f, 2.87f);

    glVertex2f(-4.94f, 2.87f);
    glVertex2f(-4.53f, 2.87f);

    glVertex2f(-4.53f, 2.87f);
    glVertex2f(-4.55f, 3.85f);

    glVertex2f(-4.55f, 3.85f);
    glVertex2f(-4.91f, 3.85f);


    glVertex2f(4.91f, 3.85f);
    glVertex2f(4.94f, 2.87f);

    glVertex2f(4.94f, 2.87f);
    glVertex2f(4.53f, 2.87f);

    glVertex2f(4.53f, 2.87f);
    glVertex2f(4.55f, 3.85f);

    glVertex2f(4.55f, 3.85f);
    glVertex2f(4.91f, 3.85f);

    glVertex2f(-5.01f, 2.81f);
    glVertex2f(-4.45f, 2.81f);

    glVertex2f(-4.45f, 2.81f);
    glVertex2f(-4.53f, 2.72f);

    glVertex2f(-4.53f, 2.72f);
    glVertex2f(-4.94f, 2.72f);

    glVertex2f(-4.94f, 2.72f);
    glVertex2f(-5.01f, 2.81f);


    glVertex2f(5.01f, 2.81f);
    glVertex2f(4.45f, 2.81f);

    glVertex2f(4.45f, 2.81f);
    glVertex2f(4.53f, 2.72f);

    glVertex2f(4.53f, 2.72f);
    glVertex2f(4.94f, 2.72f);

    glVertex2f(4.94f, 2.72f);
    glVertex2f(5.01f, 2.81f);


    glVertex2f(-4.94f, 2.65f);
    glVertex2f(-4.52f, 2.65f);

    glVertex2f(-4.52f, 2.65f);
    glVertex2f(-4.5f, 1.83f);

    glVertex2f(-4.5f, 1.83f);
    glVertex2f(-4.97f, 1.83f);

    glVertex2f(-4.97f, 1.83f);
    glVertex2f(-4.94f, 2.65f);


    glVertex2f(4.94f, 2.65f);
    glVertex2f(4.52f, 2.65f);

    glVertex2f(4.52f, 2.65f);
    glVertex2f(4.5f, 1.83f);

    glVertex2f(4.5f, 1.83f);
    glVertex2f(4.97f, 1.83f);

    glVertex2f(4.97f, 1.83f);
    glVertex2f(4.94f, 2.65f);

    glVertex2f(-5.04f, 1.75f);
    glVertex2f(-4.42f, 1.75f);

    glVertex2f(-4.42f, 1.75f);
    glVertex2f(-4.5f, 1.64f);

    glVertex2f(-4.5f, 1.64f);
    glVertex2f(-4.97f, 1.64f);

    glVertex2f(-4.97f, 1.64f);
    glVertex2f(-5.04f, 1.75f);


    glVertex2f(5.04f, 1.75f);
    glVertex2f(4.42f, 1.75f);

    glVertex2f(4.42f, 1.75f);
    glVertex2f(4.5f, 1.64f);

    glVertex2f(4.5f, 1.64f);
    glVertex2f(4.97f, 1.64f);

    glVertex2f(4.97f, 1.64f);
    glVertex2f(5.04f, 1.75f);


    glVertex2f(-4.98f, 1.57f);
    glVertex2f(-4.5f, 1.57f);

    glVertex2f(-4.5f, 1.57f);
    glVertex2f(-4.5f, 0.95f);

    glVertex2f(-4.5f, 0.95f);
    glVertex2f(-4.98f, 0.95f);

    glVertex2f(-4.98f, 0.95f);
    glVertex2f(-4.98f, 1.57f);


    glVertex2f(4.98f, 1.57f);
    glVertex2f(4.5f, 1.57f);

    glVertex2f(4.5f, 1.57f);
    glVertex2f(4.5f, 0.95f);

    glVertex2f(4.5f, 0.95f);
    glVertex2f(4.98f, 0.95f);

    glVertex2f(4.98f, 0.95f);
    glVertex2f(4.98f, 1.57f);


    glVertex2f(-3.19f, 4.15f);
    glVertex2f(-4.02f, 3.99f);

    glVertex2f(-4.02f, 3.99f);
    glVertex2f(-4.02f, 0.95f);

    glVertex2f(-4.02f, 0.95f);
    glVertex2f(-3.9f, 0.95f);

    glVertex2f(-3.9f, 0.95f);
    glVertex2f(-3.9f, 1.76f);

    glVertex2f(-3.9f, 1.76f);
    glVertex2f(-3.86f, 1.86f);

    glVertex2f(-3.86f, 1.86f);
    glVertex2f(-3.82f, 1.94f);

    glVertex2f(-3.82f, 1.94f);
    glVertex2f(-3.77f, 1.98f);

    glVertex2f(-3.77f, 1.98f);
    glVertex2f(-3.65f, 2.09f);

    glVertex2f(-3.65f, 2.09f);
    glVertex2f(-3.6f, 2.13f);

    glVertex2f(-3.6f, 2.13f);
    glVertex2f(-3.56f, 2.09f);

    glVertex2f(-3.56f, 2.09f);
    glVertex2f(-3.43f, 1.99f);

    glVertex2f(-3.43f, 1.99f);
    glVertex2f(-3.39f, 1.93f);

    glVertex2f(-3.39f, 1.93f);
    glVertex2f(-3.34f, 1.85f);

    glVertex2f(-3.34f, 1.85f);
    glVertex2f(-3.31f, 1.75f);

    glVertex2f(-3.31f, 1.75f);
    glVertex2f(-3.31f, 0.96f);

    glVertex2f(-3.31f, 0.96f);
    glVertex2f(-3.19f, 0.96f);

    glVertex2f(-3.19f, 0.96f);
    glVertex2f(-3.19f, 4.15f);


    glVertex2f(3.19f, 4.15f);
    glVertex2f(4.02f, 3.99f);

    glVertex2f(4.02f, 3.99f);
    glVertex2f(4.02f, 0.95f);

    glVertex2f(4.02f, 0.95f);
    glVertex2f(3.9f, 0.95f);

    glVertex2f(3.9f, 0.95f);
    glVertex2f(3.9f, 1.76f);

    glVertex2f(3.9f, 1.76f);
    glVertex2f(3.86f, 1.86f);

    glVertex2f(3.86f, 1.86f);
    glVertex2f(3.82f, 1.94f);

    glVertex2f(3.82f, 1.94f);
    glVertex2f(3.77f, 1.98f);

    glVertex2f(3.77f, 1.98f);
    glVertex2f(3.65f, 2.09f);

    glVertex2f(3.65f, 2.09f);
    glVertex2f(3.6f, 2.13f);

    glVertex2f(3.6f, 2.13f);
    glVertex2f(3.56f, 2.09f);

    glVertex2f(3.56f, 2.09f);
    glVertex2f(3.43f, 1.99f);

    glVertex2f(3.43f, 1.99f);
    glVertex2f(3.39f, 1.93f);

    glVertex2f(3.39f, 1.93f);
    glVertex2f(3.34f, 1.85f);

    glVertex2f(3.34f, 1.85f);
    glVertex2f(3.31f, 1.75f);

    glVertex2f(3.31f, 1.75f);
    glVertex2f(3.31f, 0.96f);

    glVertex2f(3.31f, 0.96f);
    glVertex2f(3.19f, 0.96f);

    glVertex2f(3.19f, 0.96f);
    glVertex2f(3.19f, 4.15f);

    glVertex2f(-3.84f, 0.95f);
    glVertex2f(-3.37f, 0.95f);

    glVertex2f(-3.37f, 0.95f);
    glVertex2f(-3.37f, 1.75f);

    glVertex2f(-3.37f, 1.75f);
    glVertex2f(-3.4f, 1.83f);

    glVertex2f(-3.4f, 1.83f);
    glVertex2f(-3.44f, 1.89f);

    glVertex2f(-3.44f, 1.89f);
    glVertex2f(-3.49f, 1.95f);

    glVertex2f(-3.49f, 1.95f);
    glVertex2f(-3.57f, 2.02f);

    glVertex2f(-3.57f, 2.02f);
    glVertex2f(-3.6f, 2.05f);

    glVertex2f(-3.6f, 2.05f);
    glVertex2f(-3.63f, 2.02f);

    glVertex2f(-3.63f, 2.02f);
    glVertex2f(-3.72f, 1.95f);

    glVertex2f(-3.72f, 1.95f);
    glVertex2f(-3.77f, 1.9f);

    glVertex2f(-3.77f, 1.9f);
    glVertex2f(-3.81f, 1.84f);

    glVertex2f(-3.81f, 1.84f);
    glVertex2f(-3.83f, 1.76f);

    glVertex2f(-3.83f, 1.76f);
    glVertex2f(-3.83f, 0.95f);


    glVertex2f(3.84f, 0.95f);
    glVertex2f(3.37f, 0.95f);

    glVertex2f(3.37f, 0.95f);
    glVertex2f(3.37f, 1.75f);

    glVertex2f(3.37f, 1.75f);
    glVertex2f(3.4f, 1.83f);

    glVertex2f(3.4f, 1.83f);
    glVertex2f(3.44f, 1.89f);

    glVertex2f(3.44f, 1.89f);
    glVertex2f(3.49f, 1.95f);

    glVertex2f(3.49f, 1.95f);
    glVertex2f(3.57f, 2.02f);

    glVertex2f(3.57f, 2.02f);
    glVertex2f(3.6f, 2.05f);

    glVertex2f(3.6f, 2.05f);
    glVertex2f(3.63f, 2.02f);

    glVertex2f(3.63f, 2.02f);
    glVertex2f(3.72f, 1.95f);

    glVertex2f(3.72f, 1.95f);
    glVertex2f(3.77f, 1.9f);

    glVertex2f(3.77f, 1.9f);
    glVertex2f(3.81f, 1.84f);

    glVertex2f(3.81f, 1.84f);
    glVertex2f(3.83f, 1.76f);

    glVertex2f(3.83f, 1.76f);
    glVertex2f(3.83f, 0.95f);

    glVertex2f(-3.9f, 2.4f);
    glVertex2f(-3.9f, 3.22f);

    glVertex2f(-3.9f, 3.22f);
    glVertex2f(-3.9f, 3.32f);

    glVertex2f(-3.9f, 3.32f);
    glVertex2f(-3.83f, 3.43f);

    glVertex2f(-3.83f, 3.43f);
    glVertex2f(-3.74f, 3.52f);

    glVertex2f(-3.74f, 3.52f);
    glVertex2f(-3.65f, 3.59f);

    glVertex2f(-3.65f, 3.59f);
    glVertex2f(-3.6f, 3.65f);

    glVertex2f(-3.6f, 3.65f);
    glVertex2f(-3.55f, 3.59f);

    glVertex2f(-3.55f, 3.59f);
    glVertex2f(-3.46f, 3.52f);

    glVertex2f(-3.46f, 3.52f);
    glVertex2f(-3.37f, 3.43f);

    glVertex2f(-3.37f, 3.43f);
    glVertex2f(-3.32f, 3.32f);

    glVertex2f(-3.32f, 3.32f);
    glVertex2f(-3.32f, 3.22f);

    glVertex2f(-3.32f, 3.22f);
    glVertex2f(-3.32f, 2.4f);

    glVertex2f(-3.32f, 2.4f);
    glVertex2f(-3.9f, 2.4f);


    glVertex2f(3.9f, 2.4f);
    glVertex2f(3.9f, 3.22f);

    glVertex2f(3.9f, 3.22f);
    glVertex2f(3.9f, 3.32f);

    glVertex2f(3.9f, 3.32f);
    glVertex2f(3.83f, 3.43f);

    glVertex2f(3.83f, 3.43f);
    glVertex2f(3.74f, 3.52f);

    glVertex2f(3.74f, 3.52f);
    glVertex2f(3.65f, 3.59f);

    glVertex2f(3.65f, 3.59f);
    glVertex2f(3.6f, 3.65f);

    glVertex2f(3.6f, 3.65f);
    glVertex2f(3.55f, 3.59f);

    glVertex2f(3.55f, 3.59f);
    glVertex2f(3.46f, 3.52f);

    glVertex2f(3.46f, 3.52f);
    glVertex2f(3.37f, 3.43f);

    glVertex2f(3.37f, 3.43f);
    glVertex2f(3.32f, 3.32f);

    glVertex2f(3.32f, 3.32f);
    glVertex2f(3.32f, 3.22f);

    glVertex2f(3.32f, 3.22f);
    glVertex2f(3.32f, 2.4f);

    glVertex2f(3.32f, 2.4f);
    glVertex2f(3.9f, 2.4f);

    glVertex2f(-3.84f, 2.46f);
    glVertex2f(-3.84f, 3.22f);

    glVertex2f(-3.84f, 3.22f);
    glVertex2f(-3.84f, 3.32f);

    glVertex2f(-3.84f, 3.32f);
    glVertex2f(-3.77f, 3.41f);

    glVertex2f(-3.77f, 3.41f);
    glVertex2f(-3.69f, 3.48f);

    glVertex2f(-3.69f, 3.48f);
    glVertex2f(-3.63f, 3.54f);

    glVertex2f(-3.63f, 3.54f);
    glVertex2f(-3.6f, 3.56f);

    glVertex2f(-3.6f, 3.56f);
    glVertex2f(-3.57f, 3.53f);

    glVertex2f(-3.57f, 3.53f);
    glVertex2f(-3.5f, 3.48f);

    glVertex2f(-3.5f, 3.48f);
    glVertex2f(-3.42f, 3.39f);

    glVertex2f(-3.42f, 3.39f);
    glVertex2f(-3.38f, 3.3f);

    glVertex2f(-3.38f, 3.3f);
    glVertex2f(-3.38f, 3.22f);

    glVertex2f(-3.38f, 3.22f);
    glVertex2f(-3.38f, 2.46f);

    glVertex2f(-3.38f, 2.46f);
    glVertex2f(-3.84f, 2.46f);


    glVertex2f(3.84f, 2.46f);
    glVertex2f(3.84f, 3.22f);

    glVertex2f(3.84f, 3.22f);
    glVertex2f(3.84f, 3.32f);

    glVertex2f(3.84f, 3.32f);
    glVertex2f(3.77f, 3.41f);

    glVertex2f(3.77f, 3.41f);
    glVertex2f(3.69f, 3.48f);

    glVertex2f(3.69f, 3.48f);
    glVertex2f(3.63f, 3.54f);

    glVertex2f(3.63f, 3.54f);
    glVertex2f(3.6f, 3.56f);

    glVertex2f(3.6f, 3.56f);
    glVertex2f(3.57f, 3.53f);

    glVertex2f(3.57f, 3.53f);
    glVertex2f(3.5f, 3.48f);

    glVertex2f(3.5f, 3.48f);
    glVertex2f(3.42f, 3.39f);

    glVertex2f(3.42f, 3.39f);
    glVertex2f(3.38f, 3.3f);

    glVertex2f(3.38f, 3.3f);
    glVertex2f(3.38f, 3.22f);

    glVertex2f(3.38f, 3.22f);
    glVertex2f(3.38f, 2.46f);

    glVertex2f(3.38f, 2.46f);
    glVertex2f(3.84f, 2.46f);


    glVertex2f(0.0f, 4.15f);
    glVertex2f(-3.13f, 4.15f);

    glVertex2f(-3.13f, 4.15f);
    glVertex2f(-3.13f, 0.96f);

    glVertex2f(-3.13f, 0.96f);
    glVertex2f(-2.78f, 0.96f);

    glVertex2f(-2.78f, 0.96f);
    glVertex2f(-2.78f, 1.7f);

    glVertex2f(-2.78f, 1.7f);
    glVertex2f(-2.75f, 1.83f);

    glVertex2f(-2.75f, 1.83f);
    glVertex2f(-2.7f, 1.9f);

    glVertex2f(-2.7f, 1.9f);
    glVertex2f(-2.6f, 1.99f);

    glVertex2f(-2.6f, 1.99f);
    glVertex2f(-2.47f, 2.05f);

    glVertex2f(-2.47f, 2.05f);
    glVertex2f(-2.39f, 2.09f);

    glVertex2f(-2.39f, 2.09f);
    glVertex2f(-2.35f, 2.15f);

    glVertex2f(-2.35f, 2.15f);
    glVertex2f(-2.3f, 2.1f);

    glVertex2f(-2.3f, 2.1f);
    glVertex2f(-2.23f, 2.06f);

    glVertex2f(-2.23f, 2.06f);
    glVertex2f(-2.12f, 2.0f);

    glVertex2f(-2.12f, 2.0f);
    glVertex2f(-2.0f, 1.9f);

    glVertex2f(-2.0f, 1.9f);
    glVertex2f(-1.95f, 1.83f);

    glVertex2f(-1.95f, 1.83f);
    glVertex2f(-1.92f, 1.7f);

    glVertex2f(-1.92f, 1.7f);
    glVertex2f(-1.92f, 0.95f);

    glVertex2f(-1.92f, 0.95f);
    glVertex2f(-0.98f, 0.95f);

    glVertex2f(-0.98f, 0.95f);
    glVertex2f(-0.98f, 2.77f);

    glVertex2f(-0.98f, 2.77f);
    glVertex2f(-0.96f, 2.97f);

    glVertex2f(-0.96f, 2.97f);
    glVertex2f(-0.92f, 3.12f);

    glVertex2f(-0.92f, 3.12f);
    glVertex2f(-0.82f, 3.31f);

    glVertex2f(-0.82f, 3.31f);
    glVertex2f(-0.69f, 3.46f);

    glVertex2f(-0.69f, 3.46f);
    glVertex2f(-0.52f, 3.59f);

    glVertex2f(-0.52f, 3.59f);
    glVertex2f(-0.21f, 3.77f);

    glVertex2f(-0.21f, 3.77f);
    glVertex2f(-0.06f, 3.85f);

    glVertex2f(-0.06f, 3.85f);
    glVertex2f(0.0f, 3.93f);

    glVertex2f(0.0f, 3.93f);
    glVertex2f(0.0f, 3.83f);

    glVertex2f(0.0f, 3.83f);
    glVertex2f(-0.03f, 3.8f);

    glVertex2f(-0.03f, 3.8f);
    glVertex2f(-0.16f, 3.71f);

    glVertex2f(-0.16f, 3.71f);
    glVertex2f(-0.49f, 3.53f);

    glVertex2f(-0.49f, 3.53f);
    glVertex2f(-0.64f, 3.41f);

    glVertex2f(-0.64f, 3.41f);
    glVertex2f(-0.76f, 3.27f);

    glVertex2f(-0.76f, 3.27f);
    glVertex2f(-0.85f, 3.1f);

    glVertex2f(-0.85f, 3.1f);
    glVertex2f(-0.9f, 2.97f);

    glVertex2f(-0.9f, 2.97f);
    glVertex2f(-0.9f, 0.95f);

    glVertex2f(-0.9f, 0.95f);
    glVertex2f(0.0f, 0.95f);

    glVertex2f(0.0f, 4.15f);
    glVertex2f(3.13f, 4.15f);

    glVertex2f(3.13f, 4.15f);
    glVertex2f(3.13f, 0.96f);

    glVertex2f(3.13f, 0.96f);
    glVertex2f(2.78f, 0.96f);

    glVertex2f(2.78f, 0.96f);
    glVertex2f(2.78f, 1.7f);

    glVertex2f(2.78f, 1.7f);
    glVertex2f(2.75f, 1.83f);

    glVertex2f(2.75f, 1.83f);
    glVertex2f(2.7f, 1.9f);

    glVertex2f(2.7f, 1.9f);
    glVertex2f(2.6f, 1.99f);

    glVertex2f(2.6f, 1.99f);
    glVertex2f(2.47f, 2.05f);

    glVertex2f(2.47f, 2.05f);
    glVertex2f(2.39f, 2.09f);

    glVertex2f(2.39f, 2.09f);
    glVertex2f(2.35f, 2.15f);

    glVertex2f(2.35f, 2.15f);
    glVertex2f(2.3f, 2.1f);

    glVertex2f(2.3f, 2.1f);
    glVertex2f(2.23f, 2.06f);

    glVertex2f(2.23f, 2.06f);
    glVertex2f(2.12f, 2.0f);

    glVertex2f(2.12f, 2.0f);
    glVertex2f(2.0f, 1.9f);

    glVertex2f(2.0f, 1.9f);
    glVertex2f(1.95f, 1.83f);

    glVertex2f(1.95f, 1.83f);
    glVertex2f(1.92f, 1.7f);

    glVertex2f(1.92f, 1.7f);
    glVertex2f(1.92f, 0.95f);

    glVertex2f(1.92f, 0.95f);
    glVertex2f(0.98f, 0.95f);

    glVertex2f(0.98f, 0.95f);
    glVertex2f(0.98f, 2.77f);

    glVertex2f(0.98f, 2.77f);
    glVertex2f(0.96f, 2.97f);

    glVertex2f(0.96f, 2.97f);
    glVertex2f(0.92f, 3.12f);

    glVertex2f(0.92f, 3.12f);
    glVertex2f(0.82f, 3.31f);

    glVertex2f(0.82f, 3.31f);
    glVertex2f(0.69f, 3.46f);

    glVertex2f(0.69f, 3.46f);
    glVertex2f(0.52f, 3.59f);

    glVertex2f(0.52f, 3.59f);
    glVertex2f(0.21f, 3.77f);

    glVertex2f(0.21f, 3.77f);
    glVertex2f(0.06f, 3.85f);

    glVertex2f(0.06f, 3.85f);
    glVertex2f(0.0f, 3.93f);

    glVertex2f(0.0f, 3.93f);
    glVertex2f(0.0f, 3.83f);

    glVertex2f(0.0f, 3.83f);
    glVertex2f(0.03f, 3.8f);

    glVertex2f(0.03f, 3.8f);
    glVertex2f(0.16f, 3.71f);

    glVertex2f(0.16f, 3.71f);
    glVertex2f(0.49f, 3.53f);

    glVertex2f(0.49f, 3.53f);
    glVertex2f(0.64f, 3.41f);

    glVertex2f(0.64f, 3.41f);
    glVertex2f(0.76f, 3.27f);

    glVertex2f(0.76f, 3.27f);
    glVertex2f(0.85f, 3.1f);

    glVertex2f(0.85f, 3.1f);
    glVertex2f(0.9f, 2.97f);

    glVertex2f(0.9f, 2.97f);
    glVertex2f(0.9f, 0.95f);

    glVertex2f(0.9f, 0.95f);
    glVertex2f(0.0f, 0.95f);


    glVertex2f(-2.73f, 0.96f);
    glVertex2f(-2.73f, 1.7f);

    glVertex2f(-2.73f, 1.7f);
    glVertex2f(-2.7f, 1.8f);

    glVertex2f(-2.7f, 1.8f);
    glVertex2f(-2.6f, 1.9f);

    glVertex2f(-2.6f, 1.9f);
    glVertex2f(-2.38f, 2.03f);

    glVertex2f(-2.38f, 2.03f);
    glVertex2f(-2.35f, 2.06f);

    glVertex2f(-2.35f, 2.06f);
    glVertex2f(-2.32f, 2.03f);

    glVertex2f(-2.32f, 2.03f);
    glVertex2f(-2.1f, 1.9f);

    glVertex2f(-2.1f, 1.9f);
    glVertex2f(-2.0f, 1.8f);

    glVertex2f(-2.0f, 1.8f);
    glVertex2f(-1.98f, 1.7f);

    glVertex2f(-1.98f, 1.7f);
    glVertex2f(-1.98f, 0.96f);

    glVertex2f(-1.98f, 0.96f);
    glVertex2f(-2.73f, 0.96f);


    glVertex2f(2.73f, 0.96f);
    glVertex2f(2.73f, 1.7f);

    glVertex2f(2.73f, 1.7f);
    glVertex2f(2.7f, 1.8f);

    glVertex2f(2.7f, 1.8f);
    glVertex2f(2.6f, 1.9f);

    glVertex2f(2.6f, 1.9f);
    glVertex2f(2.38f, 2.03f);

    glVertex2f(2.38f, 2.03f);
    glVertex2f(2.35f, 2.06f);

    glVertex2f(2.35f, 2.06f);
    glVertex2f(2.32f, 2.03f);

    glVertex2f(2.32f, 2.03f);
    glVertex2f(2.1f, 1.9f);

    glVertex2f(2.1f, 1.9f);
    glVertex2f(2.0f, 1.8f);

    glVertex2f(2.0f, 1.8f);
    glVertex2f(1.98f, 1.7f);

    glVertex2f(1.98f, 1.7f);
    glVertex2f(1.98f, 0.96f);

    glVertex2f(1.98f, 0.96f);
    glVertex2f(2.73f, 0.96f);

    glVertex2f(-2.78f, 2.4f);
    glVertex2f(-2.78f, 3.2f);

    glVertex2f(-2.78f, 3.2f);
    glVertex2f(-2.76f, 3.29f);

    glVertex2f(-2.76f, 3.29f);
    glVertex2f(-2.7f, 3.4f);

    glVertex2f(-2.7f, 3.4f);
    glVertex2f(-2.59f, 3.5f);

    glVertex2f(-2.59f, 3.5f);
    glVertex2f(-2.4f, 3.6f);

    glVertex2f(-2.4f, 3.6f);
    glVertex2f(-2.35f, 3.65f);

    glVertex2f(-2.35f, 3.65f);
    glVertex2f(-2.3f, 3.6f);

    glVertex2f(-2.3f, 3.6f);
    glVertex2f(-2.11f, 3.5f);

    glVertex2f(-2.11f, 3.5f);
    glVertex2f(-2.0f, 3.4f);

    glVertex2f(-2.0f, 3.4f);
    glVertex2f(-1.94f, 3.3f);

    glVertex2f(-1.94f, 3.3f);
    glVertex2f(-1.92f, 3.2f);

    glVertex2f(-1.92f, 3.2f);
    glVertex2f(-1.92f, 2.4f);

    glVertex2f(-1.92f, 2.4f);
    glVertex2f(-2.78f, 2.4f);


    glVertex2f(2.78f, 2.4f);
    glVertex2f(2.78f, 3.2f);

    glVertex2f(2.78f, 3.2f);
    glVertex2f(2.76f, 3.29f);

    glVertex2f(2.76f, 3.29f);
    glVertex2f(2.7f, 3.4f);

    glVertex2f(2.7f, 3.4f);
    glVertex2f(2.59f, 3.5f);

    glVertex2f(2.59f, 3.5f);
    glVertex2f(2.4f, 3.6f);

    glVertex2f(2.4f, 3.6f);
    glVertex2f(2.35f, 3.65f);

    glVertex2f(2.35f, 3.65f);
    glVertex2f(2.3f, 3.6f);

    glVertex2f(2.3f, 3.6f);
    glVertex2f(2.11f, 3.5f);

    glVertex2f(2.11f, 3.5f);
    glVertex2f(2.0f, 3.4f);

    glVertex2f(2.0f, 3.4f);
    glVertex2f(1.94f, 3.3f);

    glVertex2f(1.94f, 3.3f);
    glVertex2f(1.92f, 3.2f);

    glVertex2f(1.92f, 3.2f);
    glVertex2f(1.92f, 2.4f);

    glVertex2f(1.92f, 2.4f);
    glVertex2f(2.78f, 2.4f);


    glVertex2f(-2.73f, 2.45f);
    glVertex2f(-2.73f, 3.2f);

    glVertex2f(-2.73f, 3.2f);
    glVertex2f(-2.71f, 3.29f);

    glVertex2f(-2.71f, 3.29f);
    glVertex2f(-2.62f, 3.4f);

    glVertex2f(-2.62f, 3.4f);
    glVertex2f(-2.51f, 3.47f);

    glVertex2f(-2.51f, 3.47f);
    glVertex2f(-2.4f, 3.54f);

    glVertex2f(-2.4f, 3.54f);
    glVertex2f(-2.35f, 3.57f);

    glVertex2f(-2.35f, 3.57f);
    glVertex2f(-2.3f, 3.54f);

    glVertex2f(-2.3f, 3.54f);
    glVertex2f(-2.2f, 3.48f);

    glVertex2f(-2.2f, 3.48f);
    glVertex2f(-2.07f, 3.39f);

    glVertex2f(-2.07f, 3.39f);
    glVertex2f(-2.0f, 3.3f);

    glVertex2f(-2.0f, 3.3f);
    glVertex2f(-1.98f, 3.2f);

    glVertex2f(-1.98f, 3.2f);
    glVertex2f(-1.98f, 2.45f);

    glVertex2f(-1.98f, 2.45f);
    glVertex2f(-2.73f, 2.45f);


    glVertex2f(2.73f, 2.45f);
    glVertex2f(2.73f, 3.2f);

    glVertex2f(2.73f, 3.2f);
    glVertex2f(2.71f, 3.29f);

    glVertex2f(2.71f, 3.29f);
    glVertex2f(2.62f, 3.4f);

    glVertex2f(2.62f, 3.4f);
    glVertex2f(2.51f, 3.47f);

    glVertex2f(2.51f, 3.47f);
    glVertex2f(2.4f, 3.54f);

    glVertex2f(2.4f, 3.54f);
    glVertex2f(2.35f, 3.57f);

    glVertex2f(2.35f, 3.57f);
    glVertex2f(2.3f, 3.54f);

    glVertex2f(2.3f, 3.54f);
    glVertex2f(2.2f, 3.48f);

    glVertex2f(2.2f, 3.48f);
    glVertex2f(2.07f, 3.39f);

    glVertex2f(2.07f, 3.39f);
    glVertex2f(2.0f, 3.3f);

    glVertex2f(2.0f, 3.3f);
    glVertex2f(1.98f, 3.2f);

    glVertex2f(1.98f, 3.2f);
    glVertex2f(1.98f, 2.45f);

    glVertex2f(1.98f, 2.45f);
    glVertex2f(2.73f, 2.45f);

    glVertex2f(-0.7f, 0.89f);
    glVertex2f(-0.7f, 2.72f);

    glVertex2f(-0.7f, 2.72f);
    glVertex2f(-0.6f, 2.93f);

    glVertex2f(-0.6f, 2.93f);
    glVertex2f(-0.53f, 3.02f);

    glVertex2f(-0.53f, 3.02f);
    glVertex2f(-0.4f, 3.13f);

    glVertex2f(-0.4f, 3.13f);
    glVertex2f(-0.3f, 3.2f);

    glVertex2f(-0.3f, 3.2f);
    glVertex2f(-0.2f, 3.23f);

    glVertex2f(-0.2f, 3.23f);
    glVertex2f(-0.1f, 3.26f);

    glVertex2f(-0.1f, 3.26f);
    glVertex2f(0.0f, 3.26f);


    glVertex2f(0.7f, 0.89f);
    glVertex2f(0.7f, 2.72f);

    glVertex2f(0.7f, 2.72f);
    glVertex2f(0.6f, 2.93f);

    glVertex2f(0.6f, 2.93f);
    glVertex2f(0.53f, 3.02f);

    glVertex2f(0.53f, 3.02f);
    glVertex2f(0.4f, 3.13f);

    glVertex2f(0.4f, 3.13f);
    glVertex2f(0.3f, 3.2f);

    glVertex2f(0.3f, 3.2f);
    glVertex2f(0.2f, 3.23f);

    glVertex2f(0.2f, 3.23f);
    glVertex2f(0.1f, 3.26f);

    glVertex2f(0.1f, 3.26f);
    glVertex2f(0.0f, 3.26f);

    glVertex2f(0.0f, 3.2f);
    glVertex2f(-0.1f, 3.18f);

    glVertex2f(-0.1f, 3.18f);
    glVertex2f(-0.2f, 3.16f);

    glVertex2f(-0.2f, 3.16f);
    glVertex2f(-0.3f, 3.13f);

    glVertex2f(-0.3f, 3.13f);
    glVertex2f(-0.37f, 3.08f);

    glVertex2f(-0.37f, 3.08f);
    glVertex2f(-0.48f, 2.98f);

    glVertex2f(-0.48f, 2.98f);
    glVertex2f(-0.53f, 2.91f);

    glVertex2f(-0.53f, 2.91f);
    glVertex2f(-0.6f, 2.8f);

    glVertex2f(-0.6f, 2.8f);
    glVertex2f(-0.6f, 2.73f);

    glVertex2f(-0.6f, 2.73f);
    glVertex2f(-0.6f, 0.89f);


    glVertex2f(0.0f, 3.2f);
    glVertex2f(0.1f, 3.18f);

    glVertex2f(0.1f, 3.18f);
    glVertex2f(0.2f, 3.16f);

    glVertex2f(0.2f, 3.16f);
    glVertex2f(0.3f, 3.13f);

    glVertex2f(0.3f, 3.13f);
    glVertex2f(0.37f, 3.08f);

    glVertex2f(0.37f, 3.08f);
    glVertex2f(0.48f, 2.98f);

    glVertex2f(0.48f, 2.98f);
    glVertex2f(0.53f, 2.91f);

    glVertex2f(0.53f, 2.91f);
    glVertex2f(0.6f, 2.8f);

    glVertex2f(0.6f, 2.8f);
    glVertex2f(0.6f, 2.73f);

    glVertex2f(0.6f, 2.73f);
    glVertex2f(0.6f, 0.89f);

    glVertex2f(0.0f, 1.03f);
    glVertex2f(-0.42f, 1.03f);

    glVertex2f(-0.42f, 1.03f);
    glVertex2f(-0.42f, 1.83f);

    glVertex2f(-0.42f, 1.83f);
    glVertex2f(-0.41f, 1.92f);

    glVertex2f(-0.41f, 1.92f);
    glVertex2f(-0.36f, 2.0f);

    glVertex2f(-0.36f, 2.0f);
    glVertex2f(-0.28f, 2.09f);

    glVertex2f(-0.28f, 2.09f);
    glVertex2f(-0.22f, 2.14f);

    glVertex2f(-0.22f, 2.14f);
    glVertex2f(-0.08f, 2.21f);

    glVertex2f(-0.08f, 2.21f);
    glVertex2f(-0.04f, 2.24f);

    glVertex2f(-0.04f, 2.24f);
    glVertex2f(0.0f, 2.24f);


    glVertex2f(0.0f, 1.03f);
    glVertex2f(0.42f, 1.03f);

    glVertex2f(0.42f, 1.03f);
    glVertex2f(0.42f, 1.83f);

    glVertex2f(0.42f, 1.83f);
    glVertex2f(0.41f, 1.92f);

    glVertex2f(0.41f, 1.92f);
    glVertex2f(0.36f, 2.0f);

    glVertex2f(0.36f, 2.0f);
    glVertex2f(0.28f, 2.09f);

    glVertex2f(0.28f, 2.09f);
    glVertex2f(0.22f, 2.14f);

    glVertex2f(0.22f, 2.14f);
    glVertex2f(0.08f, 2.21f);

    glVertex2f(0.08f, 2.21f);
    glVertex2f(0.04f, 2.24f);

    glVertex2f(0.04f, 2.24f);
    glVertex2f(0.0f, 2.24f);

    glVertex2f(0.0f, 1.09f);
    glVertex2f(-0.36f, 1.09);

    glVertex2f(-0.36f, 1.09);
    glVertex2f(-0.36f, 1.83f);

    glVertex2f(-0.36f, 1.83f);
    glVertex2f(-0.34f, 1.92);

    glVertex2f(-0.34f, 1.92);
    glVertex2f(-0.31f, 1.98);

    glVertex2f(-0.31f, 1.98);
    glVertex2f(-0.23f, 2.05);

    glVertex2f(-0.23f, 2.05);
    glVertex2f(-0.17f, 2.1);

    glVertex2f(-0.17f, 2.1);
    glVertex2f(-0.04f, 2.16);

    glVertex2f(-0.04f, 2.16);
    glVertex2f(0.0f, 2.2);


    glVertex2f(0.0f, 1.09f);
    glVertex2f(0.36f, 1.09);

    glVertex2f(0.36f, 1.09);
    glVertex2f(0.36f, 1.83f);

    glVertex2f(0.36f, 1.83f);
    glVertex2f(0.34f, 1.92);

    glVertex2f(0.34f, 1.92);
    glVertex2f(0.31f, 1.98);

    glVertex2f(0.31f, 1.98);
    glVertex2f(0.23f, 2.05);

    glVertex2f(0.23f, 2.05);
    glVertex2f(0.17f, 2.1);

    glVertex2f(0.17f, 2.1);
    glVertex2f(0.04f, 2.16);

    glVertex2f(0.04f, 2.16);
    glVertex2f(0.0f, 2.2);

    glVertex2f(-2.88f, 4.84);
    glVertex2f(-2.88f, 4.92);

    glVertex2f(-2.88f, 4.92);
    glVertex2f(-2.84f, 5.01);

    glVertex2f(-2.84f, 5.01);
    glVertex2f(-2.8f, 5.1);

    glVertex2f(-2.8f, 5.1);
    glVertex2f(-2.75f, 5.21);

    glVertex2f(-2.75f, 5.21);
    glVertex2f(-2.69f, 5.3);

    glVertex2f(-2.69f, 5.3);
    glVertex2f(-2.6f, 5.4);

    glVertex2f(-2.6f, 5.4);
    glVertex2f(-2.43f, 5.48);

    glVertex2f(-2.43f, 5.48);
    glVertex2f(-2.37f, 5.54);

    glVertex2f(-2.37f, 5.54);
    glVertex2f(-2.33f, 5.58);

    glVertex2f(-2.33f, 5.58);
    glVertex2f(-2.25f, 5.64);

    glVertex2f(-2.25f, 5.64);
    glVertex2f(-2.25f, 5.7);

    glVertex2f(-2.25f, 5.7);
    glVertex2f(-2.28f, 5.73);

    glVertex2f(-2.28f, 5.73);
    glVertex2f(-2.31f, 5.82);

    glVertex2f(-2.31f, 5.82);
    glVertex2f(-2.28f, 5.85);

    glVertex2f(-2.28f, 5.85);
    glVertex2f(-2.24f, 5.88);

    glVertex2f(-2.24f, 5.88);
    glVertex2f(-2.24f, 5.93);

    glVertex2f(-2.24f, 5.93);
    glVertex2f(-2.24f, 6.02);

    glVertex2f(-2.24f, 6.02);
    glVertex2f(-2.18f, 6.02);

    glVertex2f(-2.18f, 6.02);
    glVertex2f(-2.18f, 5.88);

    glVertex2f(-2.18f, 5.88);
    glVertex2f(-2.14f, 5.85);

    glVertex2f(-2.14f, 5.85);
    glVertex2f(-2.12f, 5.8);

    glVertex2f(-2.12f, 5.8);
    glVertex2f(-2.12f, 5.76);

    glVertex2f(-2.12f, 5.76);
    glVertex2f(-2.14f, 5.73);

    glVertex2f(-2.14f, 5.73);
    glVertex2f(-2.18f, 5.71);

    glVertex2f(-2.18f, 5.71);
    glVertex2f(-2.18f, 5.63);

    glVertex2f(-2.18f, 5.63);
    glVertex2f(-2.15f, 5.61);

    glVertex2f(-2.15f, 5.61);
    glVertex2f(-2.12f, 5.61);

    glVertex2f(-2.12f, 5.61);
    glVertex2f(-2.07f, 5.56);

    glVertex2f(-2.07f, 5.56);
    glVertex2f(-2.02f, 5.53);

    glVertex2f(-2.02f, 5.53);
    glVertex2f(-1.99f, 5.5);

    glVertex2f(-1.99f, 5.5);
    glVertex2f(-1.95f, 5.49);

    glVertex2f(-1.95f, 5.49);
    glVertex2f(-1.9f, 5.45);

    glVertex2f(-1.9f, 5.45);
    glVertex2f(-1.86f, 5.42);

    glVertex2f(-1.86f, 5.42);
    glVertex2f(-1.82f, 5.39);

    glVertex2f(-1.82f, 5.39);
    glVertex2f(-1.79f, 5.36);

    glVertex2f(-1.79f, 5.36);
    glVertex2f(-1.76f, 5.31);


    glVertex2f(2.88f, 4.84);
    glVertex2f(2.88f, 4.92);

    glVertex2f(2.88f, 4.92);
    glVertex2f(2.84f, 5.01);

    glVertex2f(2.84f, 5.01);
    glVertex2f(2.8f, 5.1);

    glVertex2f(2.8f, 5.1);
    glVertex2f(2.75f, 5.21);

    glVertex2f(2.75f, 5.21);
    glVertex2f(2.69f, 5.3);

    glVertex2f(2.69f, 5.3);
    glVertex2f(2.6f, 5.4);

    glVertex2f(2.6f, 5.4);
    glVertex2f(2.43f, 5.48);

    glVertex2f(2.43f, 5.48);
    glVertex2f(2.37f, 5.54);

    glVertex2f(2.37f, 5.54);
    glVertex2f(2.33f, 5.58);

    glVertex2f(2.33f, 5.58);
    glVertex2f(2.25f, 5.64);

    glVertex2f(2.25f, 5.64);
    glVertex2f(2.25f, 5.7);

    glVertex2f(2.25f, 5.7);
    glVertex2f(2.28f, 5.73);

    glVertex2f(2.28f, 5.73);
    glVertex2f(2.31f, 5.82);

    glVertex2f(2.31f, 5.82);
    glVertex2f(2.28f, 5.85);

    glVertex2f(2.28f, 5.85);
    glVertex2f(2.24f, 5.88);

    glVertex2f(2.24f, 5.88);
    glVertex2f(2.24f, 5.93);

    glVertex2f(2.24f, 5.93);
    glVertex2f(2.24f, 6.02);

    glVertex2f(2.24f, 6.02);
    glVertex2f(2.18f, 6.02);

    glVertex2f(2.18f, 6.02);
    glVertex2f(2.18f, 5.88);

    glVertex2f(2.18f, 5.88);
    glVertex2f(2.14f, 5.85);

    glVertex2f(2.14f, 5.85);
    glVertex2f(2.12f, 5.8);

    glVertex2f(2.12f, 5.8);
    glVertex2f(2.12f, 5.76);

    glVertex2f(2.12f, 5.76);
    glVertex2f(2.14f, 5.73);

    glVertex2f(2.14f, 5.73);
    glVertex2f(2.18f, 5.71);

    glVertex2f(2.18f, 5.71);
    glVertex2f(2.18f, 5.63);

    glVertex2f(2.18f, 5.63);
    glVertex2f(2.15f, 5.61);

    glVertex2f(2.15f, 5.61);
    glVertex2f(2.12f, 5.61);

    glVertex2f(2.12f, 5.61);
    glVertex2f(2.07f, 5.56);

    glVertex2f(2.07f, 5.56);
    glVertex2f(2.02f, 5.53);

    glVertex2f(2.02f, 5.53);
    glVertex2f(1.99f, 5.5);

    glVertex2f(1.99f, 5.5);
    glVertex2f(1.95f, 5.49);

    glVertex2f(1.95f, 5.49);
    glVertex2f(1.9f, 5.45);

    glVertex2f(1.9f, 5.45);
    glVertex2f(1.86f, 5.42);

    glVertex2f(1.86f, 5.42);
    glVertex2f(1.82f, 5.39);

    glVertex2f(1.82f, 5.39);
    glVertex2f(1.79f, 5.36);

    glVertex2f(1.79f, 5.36);
    glVertex2f(1.76f, 5.31);

    glVertex2f(-2.8f, 4.85);
    glVertex2f(-2.79f, 4.92);

    glVertex2f(-2.79f, 4.92);
    glVertex2f(-2.78f, 4.98);

    glVertex2f(-2.78f, 4.98);
    glVertex2f(-2.76f, 5.05);

    glVertex2f(-2.76f, 5.05);
    glVertex2f(-2.73f, 5.12);

    glVertex2f(-2.73f, 5.12);
    glVertex2f(-2.7f, 5.19);

    glVertex2f(-2.7f, 5.19);
    glVertex2f(-2.65f, 5.26);

    glVertex2f(-2.65f, 5.26);
    glVertex2f(-2.59f, 5.32);

    glVertex2f(-2.59f, 5.32);
    glVertex2f(-2.51f, 5.38);

    glVertex2f(-2.51f, 5.38);
    glVertex2f(-2.44f, 5.43);

    glVertex2f(-2.44f, 5.43);
    glVertex2f(-2.39f, 5.45);

    glVertex2f(-2.39f, 5.45);
    glVertex2f(-2.34f, 5.48);

    glVertex2f(-2.34f, 5.48);
    glVertex2f(-2.3f, 5.53);

    glVertex2f(-2.3f, 5.53);
    glVertex2f(-2.27f, 5.56);

    glVertex2f(-2.27f, 5.56);
    glVertex2f(-2.19f, 5.57);

    glVertex2f(-2.19f, 5.57);
    glVertex2f(-2.14f, 5.53);

    glVertex2f(-2.14f, 5.53);
    glVertex2f(-2.1f, 5.5);

    glVertex2f(-2.1f, 5.5);
    glVertex2f(-2.01f, 5.44);

    glVertex2f(-2.01f, 5.44);
    glVertex2f(-1.97f, 5.42);

    glVertex2f(-1.97f, 5.42);
    glVertex2f(-1.92f, 5.38);

    glVertex2f(-1.92f, 5.38);
    glVertex2f(-1.86f, 5.34);

    glVertex2f(-1.86f, 5.34);
    glVertex2f(-1.82f, 5.31);

    glVertex2f(-1.82f, 5.31);
    glVertex2f(-1.73f, 5.18);


    glVertex2f(2.8f, 4.85);
    glVertex2f(2.79f, 4.92);

    glVertex2f(2.79f, 4.92);
    glVertex2f(2.78f, 4.98);

    glVertex2f(2.78f, 4.98);
    glVertex2f(2.76f, 5.05);

    glVertex2f(2.76f, 5.05);
    glVertex2f(2.73f, 5.12);

    glVertex2f(2.73f, 5.12);
    glVertex2f(2.7f, 5.19);

    glVertex2f(2.7f, 5.19);
    glVertex2f(2.65f, 5.26);

    glVertex2f(2.65f, 5.26);
    glVertex2f(2.59f, 5.32);

    glVertex2f(2.59f, 5.32);
    glVertex2f(2.51f, 5.38);

    glVertex2f(2.51f, 5.38);
    glVertex2f(2.44f, 5.43);

    glVertex2f(2.44f, 5.43);
    glVertex2f(2.39f, 5.45);

    glVertex2f(2.39f, 5.45);
    glVertex2f(2.34f, 5.48);

    glVertex2f(2.34f, 5.48);
    glVertex2f(2.3f, 5.53);

    glVertex2f(2.3f, 5.53);
    glVertex2f(2.27f, 5.56);

    glVertex2f(2.27f, 5.56);
    glVertex2f(2.19f, 5.57);

    glVertex2f(2.19f, 5.57);
    glVertex2f(2.14f, 5.53);

    glVertex2f(2.14f, 5.53);
    glVertex2f(2.1f, 5.5);

    glVertex2f(2.1f, 5.5);
    glVertex2f(2.01f, 5.44);

    glVertex2f(2.01f, 5.44);
    glVertex2f(1.97f, 5.42);

    glVertex2f(1.97f, 5.42);
    glVertex2f(1.92f, 5.38);

    glVertex2f(1.92f, 5.38);
    glVertex2f(1.86f, 5.34);

    glVertex2f(1.86f, 5.34);
    glVertex2f(1.82f, 5.31);

    glVertex2f(1.82f, 5.31);
    glVertex2f(1.73f, 5.18);

    glVertex2f(0.0f, 5.26);
    glVertex2f(-1.66f, 5.26);

    glVertex2f(-1.66f, 5.26);
    glVertex2f(-1.7f, 5.35);

    glVertex2f(-1.7f, 5.35);
    glVertex2f(-1.74f, 5.43);

    glVertex2f(-1.74f, 5.43);
    glVertex2f(-1.77f, 5.51);

    glVertex2f(-1.77f, 5.51);
    glVertex2f(-1.78f, 5.59);

    glVertex2f(-1.78f, 5.59);
    glVertex2f(-1.8f, 5.7);

    glVertex2f(-1.8f, 5.7);
    glVertex2f(-1.8f, 5.84);

    glVertex2f(-1.8f, 5.84);
    glVertex2f(-1.79f, 5.96);

    glVertex2f(-1.79f, 5.96);
    glVertex2f(-1.78f, 6.07);

    glVertex2f(-1.78f, 6.07);
    glVertex2f(-1.77f, 6.13);

    glVertex2f(-1.77f, 6.13);
    glVertex2f(-1.74f, 6.21);

    glVertex2f(-1.74f, 6.21);
    glVertex2f(-1.69f, 6.34);

    glVertex2f(-1.69f, 6.34);
    glVertex2f(-1.64f, 6.47);

    glVertex2f(-1.64f, 6.47);
    glVertex2f(-1.54f, 6.63);

    glVertex2f(-1.54f, 6.63f);
    glVertex2f(-1.43f, 6.79f);

    glVertex2f(-1.43f, 6.79f);
    glVertex2f(-1.25f, 7.0f);

    glVertex2f(-1.25f, 7.0f);
    glVertex2f(-1.05f, 7.19f);

    glVertex2f(-1.05f, 7.19f);
    glVertex2f(-0.88f, 7.31f);

    glVertex2f(-0.88f, 7.31f);
    glVertex2f(-0.73f, 7.4f);

    glVertex2f(-0.73f, 7.4f);
    glVertex2f(-0.64f, 7.38f);

    glVertex2f(-0.64f, 7.38f);
    glVertex2f(-0.5f, 7.36f);

    glVertex2f(-0.5f, 7.36f);
    glVertex2f(-0.32f, 7.35f);

    glVertex2f(-0.32f, 7.35f);
    glVertex2f(0.0f, 7.34f);

    glVertex2f(0.0f, 7.34f);
    glVertex2f(0.0f, 7.4f);

    glVertex2f(0.0f, 7.4f);
    glVertex2f(-0.3f, 7.4f);

    glVertex2f(-0.3f, 7.4f);
    glVertex2f(-0.46f, 7.42f);

    glVertex2f(-0.46f, 7.42f);
    glVertex2f(-0.67f, 7.45f);

    glVertex2f(-0.67f, 7.45f);
    glVertex2f(-0.76f, 7.5f);

    glVertex2f(-0.76f, 7.5f);
    glVertex2f(-0.74f, 7.53f);

    glVertex2f(-0.74f, 7.53f);
    glVertex2f(-0.67f, 7.55f);

    glVertex2f(-0.67f, 7.55f);
    glVertex2f(-0.58f, 7.57f);

    glVertex2f(-0.58f, 7.57f);
    glVertex2f(-0.51f, 7.6f);

    glVertex2f(-0.51f, 7.6f);
    glVertex2f(-0.42f, 7.65f);

    glVertex2f(-0.42f, 7.65f);
    glVertex2f(-0.34f, 7.7f);

    glVertex2f(-0.34f, 7.7f);
    glVertex2f(-0.29f, 7.75f);

    glVertex2f(-0.29f, 7.75f);
    glVertex2f(-0.23f, 7.81f);

    glVertex2f(-0.23f, 7.81f);
    glVertex2f(-0.17f, 7.88f);

    glVertex2f(-0.17f, 7.88f);
    glVertex2f(-0.1f, 7.86f);

    glVertex2f(-0.1f, 7.86f);
    glVertex2f(0.0f, 7.85f);

    glVertex2f(0.0f, 7.85f);
    glVertex2f(0.0f, 7.91f);

    glVertex2f(0.0f, 7.91f);
    glVertex2f(-0.07f, 7.92f);

    glVertex2f(-0.07f, 7.92f);
    glVertex2f(-0.13f, 7.93f);

    glVertex2f(-0.13f, 7.93f);
    glVertex2f(-0.13f, 7.95f);

    glVertex2f(-0.13f, 7.95f);
    glVertex2f(-0.1f, 8.0f);

    glVertex2f(-0.1f, 8.0f);
    glVertex2f(-0.05f, 8.04f);

    glVertex2f(-0.05f, 8.04f);
    glVertex2f(-0.03f, 8.05f);

    glVertex2f(-0.03f, 8.05f);
    glVertex2f(0.0f, 8.06f);


    glVertex2f(0.0f, 5.26);
    glVertex2f(1.66f, 5.26);

    glVertex2f(1.66f, 5.26);
    glVertex2f(1.7f, 5.35);

    glVertex2f(1.7f, 5.35);
    glVertex2f(1.74f, 5.43);

    glVertex2f(1.74f, 5.43);
    glVertex2f(1.77f, 5.51);

    glVertex2f(1.77f, 5.51);
    glVertex2f(1.78f, 5.59);

    glVertex2f(1.78f, 5.59);
    glVertex2f(1.8f, 5.7);

    glVertex2f(1.8f, 5.7);
    glVertex2f(1.8f, 5.84);

    glVertex2f(1.8f, 5.84);
    glVertex2f(1.79f, 5.96);

    glVertex2f(1.79f, 5.96);
    glVertex2f(1.78f, 6.07);

    glVertex2f(1.78f, 6.07);
    glVertex2f(1.77f, 6.13);

    glVertex2f(1.77f, 6.13);
    glVertex2f(1.74f, 6.21);

    glVertex2f(1.74f, 6.21);
    glVertex2f(1.69f, 6.34);

    glVertex2f(1.69f, 6.34);
    glVertex2f(1.64f, 6.47);

    glVertex2f(1.64f, 6.47);
    glVertex2f(1.54f, 6.63);

    glVertex2f(1.54f, 6.63f);
    glVertex2f(1.43f, 6.79f);

    glVertex2f(1.43f, 6.79f);
    glVertex2f(1.25f, 7.0f);

    glVertex2f(1.25f, 7.0f);
    glVertex2f(1.05f, 7.19f);

    glVertex2f(1.05f, 7.19f);
    glVertex2f(0.88f, 7.31f);

    glVertex2f(0.88f, 7.31f);
    glVertex2f(0.73f, 7.4f);

    glVertex2f(0.73f, 7.4f);
    glVertex2f(0.64f, 7.38f);

    glVertex2f(0.64f, 7.38f);
    glVertex2f(0.5f, 7.36f);

    glVertex2f(0.5f, 7.36f);
    glVertex2f(0.32f, 7.35f);

    glVertex2f(0.32f, 7.35f);
    glVertex2f(0.0f, 7.34f);

    glVertex2f(0.0f, 7.34f);
    glVertex2f(0.0f, 7.4f);

    glVertex2f(0.0f, 7.4f);
    glVertex2f(0.3f, 7.4f);

    glVertex2f(0.3f, 7.4f);
    glVertex2f(0.46f, 7.42f);

    glVertex2f(0.46f, 7.42f);
    glVertex2f(0.67f, 7.45f);

    glVertex2f(0.67f, 7.45f);
    glVertex2f(0.76f, 7.5f);

    glVertex2f(0.76f, 7.5f);
    glVertex2f(0.74f, 7.53f);

    glVertex2f(0.74f, 7.53f);
    glVertex2f(0.67f, 7.55f);

    glVertex2f(0.67f, 7.55f);
    glVertex2f(0.58f, 7.57f);

    glVertex2f(0.58f, 7.57f);
    glVertex2f(0.51f, 7.6f);

    glVertex2f(0.51f, 7.6f);
    glVertex2f(0.42f, 7.65f);

    glVertex2f(0.42f, 7.65f);
    glVertex2f(0.34f, 7.7f);

    glVertex2f(0.34f, 7.7f);
    glVertex2f(0.29f, 7.75f);

    glVertex2f(0.29f, 7.75f);
    glVertex2f(0.23f, 7.81f);

    glVertex2f(0.23f, 7.81f);
    glVertex2f(0.17f, 7.88f);

    glVertex2f(0.17f, 7.88f);
    glVertex2f(0.1f, 7.86f);

    glVertex2f(0.1f, 7.86f);
    glVertex2f(0.0f, 7.85f);

    glVertex2f(0.0f, 7.85f);
    glVertex2f(0.0f, 7.91f);

    glVertex2f(0.0f, 7.91f);
    glVertex2f(0.07f, 7.92f);

    glVertex2f(0.07f, 7.92f);
    glVertex2f(0.13f, 7.93f);

    glVertex2f(0.13f, 7.93f);
    glVertex2f(0.13f, 7.95f);

    glVertex2f(0.13f, 7.95f);
    glVertex2f(0.1f, 8.0f);

    glVertex2f(0.1f, 8.0f);
    glVertex2f(0.05f, 8.04f);

    glVertex2f(0.05f, 8.04f);
    glVertex2f(0.03f, 8.05f);

    glVertex2f(0.03f, 8.05f);
    glVertex2f(0.0f, 8.06f);

    glVertex2f(-1.74f, 5.3f);
    glVertex2f(-1.76f, 5.34f);

    glVertex2f(-1.76f, 5.34f);
    glVertex2f(-1.78f, 5.39f);

    glVertex2f(-1.78f, 5.39f);
    glVertex2f(-1.8f, 5.44f);

    glVertex2f(-1.8f, 5.44f);
    glVertex2f(-1.83f, 5.56f);

    glVertex2f(-1.83f, 5.56f);
    glVertex2f(-1.84f, 5.66f);

    glVertex2f(-1.84f, 5.66f);
    glVertex2f(-1.86f, 5.78f);

    glVertex2f(-1.86f, 5.78f);
    glVertex2f(-1.85f, 5.9f);

    glVertex2f(-1.85f, 5.9f);
    glVertex2f(-1.84f, 6.06f);

    glVertex2f(-1.84f, 6.06f);
    glVertex2f(-1.82f, 6.15f);

    glVertex2f(-1.82f, 6.15f);
    glVertex2f(-1.78f, 6.28f);

    glVertex2f(-1.78f, 6.28f);
    glVertex2f(-1.73f, 6.42f);

    glVertex2f(-1.73f, 6.42f);
    glVertex2f(-1.66f, 6.56f);

    glVertex2f(-1.66f, 6.56f);
    glVertex2f(-1.58f, 6.69f);

    glVertex2f(-1.58f, 6.69f);
    glVertex2f(-1.49f, 6.82f);

    glVertex2f(-1.49f, 6.82f);
    glVertex2f(-1.38f, 6.96f);

    glVertex2f(-1.38f, 6.96f);
    glVertex2f(-1.21f, 7.14f);

    glVertex2f(-1.21f, 7.14f);
    glVertex2f(-1.07f, 7.25f);

    glVertex2f(-1.07f, 7.25f);
    glVertex2f(-0.96f, 7.34f);

    glVertex2f(-0.96f, 7.34f);
    glVertex2f(-0.83f, 7.42f);

    glVertex2f(-0.83f, 7.42f);
    glVertex2f(-0.77f, 7.43f);

    glVertex2f(-0.77f, 7.43f);
    glVertex2f(-0.82f, 7.48f);

    glVertex2f(-0.82f, 7.48f);
    glVertex2f(-0.83f, 7.5f);

    glVertex2f(-0.83f, 7.5f);
    glVertex2f(-0.77f, 7.58f);

    glVertex2f(-0.77f, 7.58f);
    glVertex2f(-0.61f, 7.63f);

    glVertex2f(-0.61f, 7.63f);
    glVertex2f(-0.52f, 7.66f);

    glVertex2f(-0.52f, 7.66f);
    glVertex2f(-0.45f, 7.69f);

    glVertex2f(-0.45f, 7.69f);
    glVertex2f(-0.4f, 7.75f);

    glVertex2f(-0.4f, 7.75f);
    glVertex2f(-0.32f, 7.81f);

    glVertex2f(-0.32f, 7.81f);
    glVertex2f(-0.2f, 7.93f);

    glVertex2f(-0.2f, 7.93f);
    glVertex2f(-0.18f, 7.98f);

    glVertex2f(-0.18f, 7.98f);
    glVertex2f(-0.17f, 8.02f);

    glVertex2f(-0.17f, 8.02f);
    glVertex2f(-0.12f, 8.07f);

    glVertex2f(-0.12f, 8.07f);
    glVertex2f(-0.07f, 8.1f);

    glVertex2f(-0.07f, 8.1f);
    glVertex2f(0.0f, 8.1f);

    glVertex2f(1.74f, 5.3f);
    glVertex2f(1.76f, 5.34f);

    glVertex2f(1.76f, 5.34f);
    glVertex2f(1.78f, 5.39f);

    glVertex2f(1.78f, 5.39f);
    glVertex2f(1.8f, 5.44f);

    glVertex2f(1.8f, 5.44f);
    glVertex2f(1.83f, 5.56f);

    glVertex2f(1.83f, 5.56f);
    glVertex2f(1.84f, 5.66f);

    glVertex2f(1.84f, 5.66f);
    glVertex2f(1.86f, 5.78f);

    glVertex2f(1.86f, 5.78f);
    glVertex2f(1.85f, 5.9f);

    glVertex2f(1.85f, 5.9f);
    glVertex2f(1.84f, 6.06f);

    glVertex2f(1.84f, 6.06f);
    glVertex2f(1.82f, 6.15f);

    glVertex2f(1.82f, 6.15f);
    glVertex2f(1.78f, 6.28f);

    glVertex2f(1.78f, 6.28f);
    glVertex2f(1.73f, 6.42f);

    glVertex2f(1.73f, 6.42f);
    glVertex2f(1.66f, 6.56f);

    glVertex2f(1.66f, 6.56f);
    glVertex2f(1.58f, 6.69f);

    glVertex2f(1.58f, 6.69f);
    glVertex2f(1.49f, 6.82f);

    glVertex2f(1.49f, 6.82f);
    glVertex2f(1.38f, 6.96f);

    glVertex2f(1.38f, 6.96f);
    glVertex2f(1.21f, 7.14f);

    glVertex2f(1.21f, 7.14f);
    glVertex2f(1.07f, 7.25f);

    glVertex2f(1.07f, 7.25f);
    glVertex2f(0.96f, 7.34f);

    glVertex2f(0.96f, 7.34f);
    glVertex2f(0.83f, 7.42f);

    glVertex2f(0.83f, 7.42f);
    glVertex2f(0.77f, 7.43f);

    glVertex2f(0.77f, 7.43f);
    glVertex2f(0.82f, 7.48f);

    glVertex2f(0.82f, 7.48f);
    glVertex2f(0.83f, 7.5f);

    glVertex2f(0.83f, 7.5f);
    glVertex2f(0.77f, 7.58f);

    glVertex2f(0.77f, 7.58f);
    glVertex2f(0.61f, 7.63f);

    glVertex2f(0.61f, 7.63f);
    glVertex2f(0.52f, 7.66f);

    glVertex2f(0.52f, 7.66f);
    glVertex2f(0.45f, 7.69f);

    glVertex2f(0.45f, 7.69f);
    glVertex2f(0.4f, 7.75f);

    glVertex2f(0.4f, 7.75f);
    glVertex2f(0.32f, 7.81f);

    glVertex2f(0.32f, 7.81f);
    glVertex2f(0.2f, 7.93f);

    glVertex2f(0.2f, 7.93f);
    glVertex2f(0.18f, 7.98f);

    glVertex2f(0.18f, 7.98f);
    glVertex2f(0.17f, 8.02f);

    glVertex2f(0.17f, 8.02f);
    glVertex2f(0.12f, 8.07f);

    glVertex2f(0.12f, 8.07f);
    glVertex2f(0.07f, 8.1f);

    glVertex2f(0.07f, 8.1f);
    glVertex2f(0.0f, 8.1f);

    glVertex2f(-0.02f, 8.32f);
    glVertex2f(-0.02f, 8.35f);

    glVertex2f(0.02f, 8.32f);
    glVertex2f(0.02f, 8.35f);



    glVertex2f(-0.02f, 8.54f);
    glVertex2f(-0.02f, 8.67f);

    glVertex2f(-0.02f, 8.67f);
    glVertex2f(0.0f, 8.69f);

    glVertex2f(0.02f, 8.54f);
    glVertex2f(0.02f, 8.67f);

    glVertex2f(0.02f, 8.67f);
    glVertex2f(0.0f, 8.69f);

    glEnd();

}